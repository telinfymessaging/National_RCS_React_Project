import React from 'react'

const page = () => {
  return (
    <div>dashboard</div>
  )
}

export default page