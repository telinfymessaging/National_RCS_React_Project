import React from 'react'

const page = () => {
  return (
    <div>account-setting</div>
  )
}

export default page